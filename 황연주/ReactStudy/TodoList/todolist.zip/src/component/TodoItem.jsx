import "./TodoItem.css";
import { useEffect } from "react";

const TodoItem = ({ id, content, isDone, date, onUpdate, onDelete }) => {
  useEffect(() => {
    console.log("content", content);
  }, [content]);
  const onChangeCheckbox = () => {
    onUpdate(id);
  };
  const onClickDeleteButton = () => {
    onDelete(id);
  };
  return (
    <div className="TodoItem">
      <div>
        <input onChange={onChangeCheckbox} checked={isDone} type="checkbox" />
        <div className={`list__title ${isDone ? "done" : ""}`}>{content}</div>
      </div>
      <div>
        <span>{new Date(date).toLocaleDateString()}</span>
        <div className="btn__col">
          <button onClick={onClickDeleteButton}>X</button>
        </div>
      </div>
    </div>
  );
};
export default TodoItem;
